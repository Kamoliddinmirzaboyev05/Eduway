import React from 'react'
import "./Home.css"
function Home() {
  return (
    <div className='homePage'>
      <div className="homeHero">
        <div className="container">
          <h1>Home page</h1>
        </div>
      </div>
    </div>
  )
}

export default Home