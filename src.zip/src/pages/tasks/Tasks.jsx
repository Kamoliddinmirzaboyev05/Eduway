import React from 'react'

function Tasks() {
  return (
    <div>Tasks</div>
  )
}

export default Tasks