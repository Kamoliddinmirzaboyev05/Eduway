import React from 'react'

function Builder() {
  return (
    <div>Builder</div>
  )
}

export default Builder